package com.viaversion.viaalpha.protocol.version;

import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;

public class ProtocolVersionAlpha {
    // Версия протокола Alpha 1.2.6 (условный номер)
    public static final ProtocolVersion ALPHA_1_2_6 = new ProtocolVersion(2, "Alpha 1.2.6");
}
